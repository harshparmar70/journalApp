package com.harsh.journalApp.controller;

import com.harsh.journalApp.entity.JournalEntry;
import com.harsh.journalApp.service.JournalEntryService;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/journal")
public class JournalEntryController {

    @Autowired
    private JournalEntryService journalEntryService;


    @GetMapping
    public ResponseEntity<List<JournalEntry>> getAll(){
        List<JournalEntry> all = journalEntryService.getAll();
        if(all != null){
            return ResponseEntity.ok(all);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<?> createEntry(@RequestBody JournalEntry myEntry  ){
        try {
            journalEntryService.saveEntry(myEntry);
            return ResponseEntity.status(HttpStatus.CREATED).body(myEntry);

        }catch (Exception e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }

    }
    @GetMapping("id/{myid}")
    public ResponseEntity<JournalEntry> findById(@PathVariable ObjectId myid){
        Optional<JournalEntry> journalEntry = journalEntryService.getByID(myid);
        if (journalEntry.isPresent()){
            return new ResponseEntity<>(journalEntry.get(), HttpStatus.OK);
        }else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("id/{myid}")
    public ResponseEntity<?> deleteEntryById(@PathVariable ObjectId myid){
        journalEntryService.deleteById(myid);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("id/{myid}")
    public ResponseEntity<?> updateByid(@PathVariable ObjectId myid,@RequestBody JournalEntry newEntity) {
        JournalEntry old = journalEntryService.getByID(myid).orElse(null);
        if (old != null) {
            old.setTitle(
                    newEntity.getTitle() != null && !newEntity.getTitle().isEmpty()
                            ? newEntity.getTitle()
                            : old.getTitle()
            );
            old.setContent(
                    newEntity.getContent() != null && !newEntity.getContent().isEmpty()
                            ? newEntity.getContent()
                            : old.getContent()
            );
            old.setData(LocalDateTime.now());
            journalEntryService.saveEntry(old);
            return ResponseEntity.ok(old);
        }
        return  ResponseEntity.notFound().build();
    }



}
